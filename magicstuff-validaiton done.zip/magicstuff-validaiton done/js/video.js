$(document).ready(function(){
      $('.roundabout-holder').roundabout({
      	 btnPrev: ".prev",
         btnNext: ".next"
      });
});