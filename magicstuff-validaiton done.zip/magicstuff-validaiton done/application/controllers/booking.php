<?PHP

class Booking extends Controller{

	function index()
	{
		$this->load->view('booking');		
	}

}
?>