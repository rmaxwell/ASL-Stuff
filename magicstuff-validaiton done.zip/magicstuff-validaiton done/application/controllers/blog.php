<?PHP

class Blog extends Controller{

	function index()
	{
		$this->load->view('blog');		
	}

}
?>