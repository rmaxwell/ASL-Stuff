<?PHP

class Videos extends Controller{

	function index()
	{
		$this->load->view('videos');		
	}

}
?>