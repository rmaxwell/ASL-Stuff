<?PHP

class Bio extends Controller{

	function index()
	{
		$this->load->view('bio');		
	}

}
?>