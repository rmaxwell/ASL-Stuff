<?php class Login extends Controller {

	//Form button fire up validation_credentials function
	function validate_credentials()
	{
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('username', 'Username', 'callback_username_check');
		$this->form_validation->set_rules('password', 'Password','callback_password_check');
		
		//BEFORE NEXT LINE HAPPENS, 
		//Two callback function have to be true first before run is == TRUE
		//Look at the next two functon first then read next line
		if($this->form_validation->run() == TRUE)
		{
			$data = array(
				'username' => $this->input->post('username'),
				'is_logged_in' => true
				);
			$this->session->set_userdata($data);
			redirect('/admin/site');
		}else{
			// incorrect username or password
			$this->form_validation->set_message('username_check', 'User Name or Password is not correct');		
			$data['main_content'] = 'admin/login_form';
			$data['title'] = 'STUFF the Magic Mascot | Login | Content Management System';
			$this->load->view('admin/includes/temp_min', $data);	
		}
	}

	public function username_check($str)
	{
		$pattern = "/^[a-z0-9_-]{6,32}$/";		
		if (preg_match($pattern, $str))
		{
			if(!empty($_POST['password'])){
				$this->load->model('admin/membership_model');
				$query = $this->membership_model->validate();
				
				if($query){
					return TRUE;//LOGIN IN PASS
				}else{
					$this->form_validation->set_message('username_check', 'Incorrect username or password');
					return FALSE;//LOGIN IN FAILD
				}
			}else{
				return TRUE;//becuase function password_check will return false
			}
		}
		//pattern dose not match, do not bother with checking data base
		else{
			if(empty($_POST['username'])){
				$this->form_validation->set_message('username_check', 'Username field is blank');
				return FALSE;
			}else{
				if(empty($_POST['password'])){
					return TRUE;//becuase function password_check will return false
				}else{
					$this->form_validation->set_message('username_check', 'Incorrect username or password');
					return FALSE;
				}
			}
		}
	}
	public function password_check($str)
	{
		if(empty($str)){	
			$this->form_validation->set_message('password_check', 'Password field is blank');
			return FALSE;
		}
	}

	function logout()
	{
		//redirect
		$this->session->sess_destroy();
		$data['main_content'] = 'admin/login_form';
		$data['title'] = 'STUFF the Magic Mascot | Login | Content Management System';
		$this->load->view('admin/includes/temp_min', $data);
	}
}