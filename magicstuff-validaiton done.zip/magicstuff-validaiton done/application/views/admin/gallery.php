<div class="wrapper">
<h1>Gallery</h1>

<!--View Image Gallery-->
<!--If there are no images-->
	<?php if(isset($images) && count($images) == 0){ ?>
	<fieldset>
		<legend><h2><?=$album[0]['album_title']?></h2></legend>
			<legend>Upload Images</legend>

<!--If there are images-->
	<?php }else{ ?>
	<fieldset>
		<legend class="album_heading"><?=$album[0]['album_title']?></legend>
			<div class="edit_img">
				<div>
					<a href="" class="prev"></a>
				</div>
					<img src="" class="edit_image"/>
				<div>
					<a href="" class="next"></a>
				</div>
				<form class="gallery_info" method="post" action="<?=base_url()?>index.php/admin/gallery/update_image/<?=$album[0]['album_id']?>/">
					<input id="image_title" type="text" name="image_title" size="20" placeholder="Enter Image Title" value="">
					<input type="submit" value="Save Changes">
				   	<a href="<?=base_url();?>index.php/admin/gallery/delete_image/<?=$album[0]['album_id']?>/" class="delete_image" >Delete Image</a>
				</form>
			</div>
	 </fieldset>
			
			<div class="images">
				<?php for ($i=0; $i<count($images); $i++){ 
                      $id = $images[$i]['photo_id']; ?>
                    <a href="<?=base_url().$images[$i]['photo_path'];?>" image-Index="<?=$images[$i]['photo_id'];?>" alt="<?=$images[$i]['photo_title'];?>" >
                        <img src="<?=base_url().$images[$i]['photo_tn'];?>" style="width: 50px; height: 72px" alt="<?=$images[$i]['photo_title'];?>" />
                    </a>
                <?php } ?>
			</div>

			<fieldset><legend>Upload More Images</legend>
<?php } ?>
				<?php   $inputFiles = array ('name'=> 'userfile[]',
											'id'	=> 'userfile',
											'accept' => 'image/*',
											'multiple' => 'multiple');
						
						//$hidden = codeInighter ( name="" => value="")
						$hidden = array ('album_name' => $album[0]['album_title']);
											
							
						echo form_open_multipart(base_url().'index.php/admin/gallery/upload/'.$album[0]["album_id"],'',$hidden);
						echo form_error('userfile[]');
						echo form_upload($inputFiles);
						echo form_submit('submit', 'Upload');
						echo form_close();
				?> 
			</fieldset>	
</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>

<script type="text/javascript" src="<?=base_url()?>js/admin/gallery.js"></script>