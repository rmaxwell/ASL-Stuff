<?php $this->load->view('admin/includes/header');
	$this->load->view($main_content);
	$this->load->view('admin/includes/footer'); ?>