<h1>Album Information</h1>
<div class="wrapper">

<fieldset>
    <legend>Add a new Photo Album</legend>
    <?php
		$albumInput = array ('name'=> 'newAlbum',
							'id'	=> 'newAlbum',
							'value' => set_value('newAlbum'),
							'placeholder' => 'Enter Album Name',
							'size'=>'20');

		echo form_open('admin/gallery/add_album');
		echo form_error('newAlbum');
		echo form_input($albumInput);
		echo form_submit('submit', 'Add New Album Name');
		echo form_close();
	?> 
</fieldset>	

<?php if(count($album_title) > 0){ ?>
	<fieldset>
	    <legend>Click Album Title to View and Edit Images</legend>
	   		<div class="images">
	   		<?php for ($ii=0; $ii<count($album_title); $ii++){ ?>
	   		<h1 class="gallery_album"><a href="gallery/load_album/<?=$album_title[$ii]['album_id']?>"><?=$album_title[$ii]['album_title']?></a></h1>
	   		<a href="gallery/delete_album/<?=$album_title[$ii]['album_id'].'/'.$album_title[$ii]['album_title']?>" class="delete_album">Delete Album</a>
	   		<?php } ?></div>
	</fieldset>
<?php } ?>
</div>