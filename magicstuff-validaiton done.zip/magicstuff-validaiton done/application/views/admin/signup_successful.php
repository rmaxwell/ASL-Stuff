<div id="signup_successful">
	<h1>Congrats!</h1>
	<p>Your account has not been created. <?php echo anchor('admin', 'Login Now');?></p>
</div>